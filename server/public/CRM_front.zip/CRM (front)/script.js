// script.js
document.addEventListener('DOMContentLoaded', function () {
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');
    const submitButton = document.getElementById('submitButton');
    const emailError = document.getElementById('emailError');

    function validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(String(email).toLowerCase());
    }

    function updateButtonState() {
        submitButton.disabled = !(validateEmail(emailInput.value) && passwordInput.value);
    }

    emailInput.addEventListener('input', function () {
        if (validateEmail(emailInput.value)) {
            emailError.style.display = 'none';
        } else {
            emailError.style.display = 'block';
        }
        updateButtonState();
    });

    passwordInput.addEventListener('input', updateButtonState);

    document.getElementById('loginForm').addEventListener('submit', function (e) {
        e.preventDefault();

        const authReqData = {
            nickname: emailInput.value,
            password: passwordInput.value,
            organisation: 'UFIT_PRO'
        };

        axios.post('http://127.0.0.1:3000/auth', authReqData, {
            headers: {
                'Content-Type': 'application/json'
            }
        })
        .then(function (response) {
            // Если авторизация успешна, перенаправляем на index.html
            window.location.href = 'index.html';
        })
        .catch(function (error) {
            let errorMessage = 'Ошибка авторизации'; // Стандартное сообщение об ошибке

            if (error.response) {
                // Проверяем, есть ли ответ от сервера и его формат
                if (error.response.data && typeof error.response.data === 'string') {
                    // Если ответ сервера в формате HTML, используем его как сообщение об ошибке
                    errorMessage = error.response.data;
                } else if (error.response.data.message) {
                    // Если в ответе сервера есть сообщение об ошибке
                    errorMessage = error.response.data.message;
                }
            }

            // Показать уведомление об ошибке
            alert(errorMessage);
            // Перезагрузка страницы
            window.location.reload();
        });
    });
});

import {
  require_react
} from "./chunk-7VNOU2QA.js";
import "./chunk-P2LSHJDD.js";
export default require_react();
//# sourceMappingURL=react.js.map
